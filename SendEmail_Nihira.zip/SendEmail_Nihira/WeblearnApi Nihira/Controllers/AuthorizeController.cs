﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using WeblearnApi_Nihira.Modal;
using WeblearnApi_Nihira.Repos;

namespace WeblearnApi_Nihira.Controllers
{
 [Route("api/[controller]")]
 [ApiController]
 public class AuthorizeController : ControllerBase
 {
  private readonly LearndataContext _context;
  private readonly JwtSettings _jwtSettings;

  public AuthorizeController(LearndataContext context, IOptions<JwtSettings> options)
  {
   _context = context;
   _jwtSettings = options.Value;
  }
  [HttpPost("GenerateToken")]
  public async Task<IActionResult> GenerateToken([FromBody] UserCred userCred)
  {
   
   var user = await _context.TblUsers.FirstOrDefaultAsync(
    item => item.Username == userCred.userName && item.Password == userCred.password
    ) ;
   if (user!= null)
   {
    //generate token
    var tokenhandler = new JwtSecurityTokenHandler();
    var tokenkey = Encoding.UTF8.GetBytes(_jwtSettings.securitykey);
    var tokendesc = new SecurityTokenDescriptor
    {
     Subject = new ClaimsIdentity(new Claim[]
     {
      new Claim(ClaimTypes.Name, user.Username),
      new Claim(ClaimTypes.Role, user.Role)

     }),
     Expires = DateTime.UtcNow.AddSeconds(30),
     SigningCredentials = new SigningCredentials(
      new SymmetricSecurityKey(tokenkey),
      SecurityAlgorithms.HmacSha256)
    };
    var token = tokenhandler.CreateToken(tokendesc);
    var finaltoken = tokenhandler.WriteToken(token);
    return Ok(finaltoken) ;

   }
   else
   {
    return Unauthorized();
   }
  }
 }
}
