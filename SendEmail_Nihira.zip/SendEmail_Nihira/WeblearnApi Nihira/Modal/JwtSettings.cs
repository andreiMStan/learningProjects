﻿namespace WeblearnApi_Nihira.Modal
{
 public class JwtSettings
 {
        public string securitykey { get; set; }
    }
}
