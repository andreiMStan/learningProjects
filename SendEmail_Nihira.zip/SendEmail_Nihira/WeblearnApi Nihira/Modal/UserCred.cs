﻿namespace WeblearnApi_Nihira.Modal
{
 public class UserCred
 {
        public string userName { get; set; }
        public string  password { get; set; }
    }
}
