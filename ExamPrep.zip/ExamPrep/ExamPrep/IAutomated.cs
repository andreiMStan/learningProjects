﻿namespace ExamPrep
{
 public interface IAutomated
 {
  public string autoInfo();
 }
}